# copiato da hello-world
cambio la descrizione in il box di villa
no
Branching is the way to work on different versions of a repository at one time.

working directory  <<<----checkout------REPOSITORY on GITHUB
        |                                        |
        --stage ---->STAGING AREA ----committ -->
By default your repository has one branch named master which is considered to be the definitive branch. We use branches to experiment and make edits before committing them to master.
On GitHub, saved changes are called commits. Each commit has an associated commit message, which is a description explaining why a particular change was made. Commit messages capture the history of your changes  cosi gli altri possono capiire il motivo.

nel giugno 2020 riprendo questo progetto git con l'intento di imparare e abituarmi ad usare git.
immagino di dover scrivere un libro, fatto di vari capitoli.
mi riprometto di scrivere almeno un capitolo con VIM

25/6 :  utilizzo  il desktop HP , con GIThub desltop e Atom  come editor.
      è la seconda prova dopo la ripresa.
